#pragma once
#include <string>
using namespace std;

enum Degree { SECURITY, NETWORK, SOFTWARE };

// Establish degree types and their associated strings per requirement C
static const string degreeStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };